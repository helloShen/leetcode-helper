/**
 * Problem Interface
 */
package com.ciaoshen.leetcode.util;

/**
 * Problem 只是一个挂名的接口，目前还没有实质性的成员
 */
public interface Problem { }
